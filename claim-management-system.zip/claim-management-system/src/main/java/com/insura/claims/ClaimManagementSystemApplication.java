package com.insura.claims;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClaimManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClaimManagementSystemApplication.class, args);
	}

}
