package com.insura.claims;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClaimManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
